# Vehicle Management System

![PHP CI](https://github.com/ayik/vehicle-management-system/workflows/PHP%20CI/badge.svg)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A PHP/MySQL based vehicle management system with booking and maintenance tracking.

## Features
- Vehicle registration and management
- Maintenance tracking
- Booking system 
- User-friendly interface
- Bootstrap styling

## Requirements
- PHP 7.4+
- MySQL 5.7+
- Web server (Apache/Nginx)

## Quick Start
1. Clone the repository
```bash
git clone https://github.com/ayik/vehicle-management-system.git