<?php
include_once 'config/database.php';
include_once 'classes/Vehicle.php';

$database = new Database();
$db = $database->getConnection();
$vehicle = new Vehicle($db);

$page_title = "Vehicle Management System";
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $page_title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1><?php echo $page_title; ?></h1>
        
        <!-- Add Vehicle Form -->
        <div class="card mb-4">
            <div class="card-header">
                <h2>Add New Vehicle</h2>
            </div>
            <div class="card-body">
                <form action="create_vehicle.php" method="post">
                    <div class="mb-3">
                        <label>Vehicle Number</label>
                        <input type="text" name="vehicle_number" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Model</label>
                        <input type="text" name="model" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Brand</label>
                        <input type="text" name="brand" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Year</label>
                        <input type="number" name="year" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="available">Available</option>
                            <option value="maintenance">Maintenance</option>
                            <option value="in_use">In Use</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Vehicle</button>
                </form>
            </div>
        </div>

        <!-- Vehicle List -->
        <div class="card">
            <div class="card-header">
                <h2>Vehicle List</h2>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Vehicle Number</th>
                            <th>Model</th>
                            <th>Brand</th>
                            <th>Year</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $stmt = $vehicle->read();
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            extract($row);
                            echo "<tr>";
                            echo "<td>{$vehicle_number}</td>";
                            echo "<td>{$model}</td>";
                            echo "<td>{$brand}</td>";
                            echo "<td>{$year}</td>";
                            echo "<td>{$status}</td>";
                            echo "<td>";
                            echo "<a href='edit_vehicle.php?id={$id}' class='btn btn-sm btn-primary me-2'>Edit</a>";
                            echo "<a href='delete_vehicle.php?id={$id}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure?\")'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>