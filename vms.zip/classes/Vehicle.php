<?php
class Vehicle {
    private $conn;
    private $table_name = "vehicles";

    public $id;
    public $vehicle_number;
    public $model;
    public $brand;
    public $year;
    public $status;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Create vehicle
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                (vehicle_number, model, brand, year, status) 
                VALUES (:vehicle_number, :model, :brand, :year, :status)";

        $stmt = $this->conn->prepare($query);

        // Sanitize inputs
        $this->vehicle_number = htmlspecialchars(strip_tags($this->vehicle_number));
        $this->model = htmlspecialchars(strip_tags($this->model));
        $this->brand = htmlspecialchars(strip_tags($this->brand));
        $this->year = htmlspecialchars(strip_tags($this->year));
        $this->status = htmlspecialchars(strip_tags($this->status));

        // Bind values
        $stmt->bindParam(":vehicle_number", $this->vehicle_number);
        $stmt->bindParam(":model", $this->model);
        $stmt->bindParam(":brand", $this->brand);
        $stmt->bindParam(":year", $this->year);
        $stmt->bindParam(":status", $this->status);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Read all vehicles
    public function read() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Read single vehicle
    public function readOne() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = ? LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        $this->vehicle_number = $row['vehicle_number'];
        $this->model = $row['model'];
        $this->brand = $row['brand'];
        $this->year = $row['year'];
        $this->status = $row['status'];
    }

    // Update vehicle
    public function update() {
        $query = "UPDATE " . $this->table_name . " 
                SET vehicle_number = :vehicle_number, 
                    model = :model, 
                    brand = :brand, 
                    year = :year, 
                    status = :status 
                WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        // Sanitize inputs
        $this->vehicle_number = htmlspecialchars(strip_tags($this->vehicle_number));
        $this->model = htmlspecialchars(strip_tags($this->model));
        $this->brand = htmlspecialchars(strip_tags($this->brand));
        $this->year = htmlspecialchars(strip_tags($this->year));
        $this->status = htmlspecialchars(strip_tags($this->status));
        $this->id = htmlspecialchars(strip_tags($this->id));

        // Bind values
        $stmt->bindParam(":vehicle_number", $this->vehicle_number);
        $stmt->bindParam(":model", $this->model);
        $stmt->bindParam(":brand", $this->brand);
        $stmt->bindParam(":year", $this->year);
        $stmt->bindParam(":status", $this->status);
        $stmt->bindParam(":id", $this->id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Delete vehicle
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(1, $this->id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }
}
?>