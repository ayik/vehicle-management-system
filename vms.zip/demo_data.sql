-- Sample data for vehicles table
INSERT INTO vehicles (vehicle_number, model, brand, year, status) VALUES
('ABC123', 'Camry', 'Toyota', 2023, 'available'),
('XYZ789', 'Model 3', 'Tesla', 2024, 'in_use'),
('DEF456', 'Civic', 'Honda', 2022, 'maintenance'),
('GHI789', 'X5', 'BMW', 2023, 'available'),
('JKL012', 'F-150', 'Ford', 2024, 'available');

-- Sample data for maintenance table
INSERT INTO maintenance (vehicle_id, maintenance_date, description, cost) VALUES
(1, '2025-02-15', 'Regular oil change and inspection', 150.00),
(3, '2025-03-01', 'Brake pad replacement', 350.00),
(2, '2025-02-28', 'Software update and charging system check', 200.00);

-- Sample data for bookings table
INSERT INTO bookings (vehicle_id, user_name, start_date, end_date, purpose, status) VALUES
(2, 'ayik', '2025-03-03 09:00:00', '2025-03-05 18:00:00', 'Business trip', 'approved'),
(4, 'john_doe', '2025-03-10 08:00:00', '2025-03-11 17:00:00', 'Client meeting', 'pending'),
(1, 'sarah_smith', '2025-03-15 10:00:00', '2025-03-15 19:00:00', 'Local delivery', 'pending');