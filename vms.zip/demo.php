<?php
session_start();
include_once 'config/database.php';
include_once 'classes/Vehicle.php';

// Set default user for demo
$_SESSION['user'] = 'ayik';
$_SESSION['is_admin'] = true;

$database = new Database();
$db = $database->getConnection();

// Get current UTC time
$current_utc = '2025-03-03 16:09:25';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vehicle Management System - Demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">VehicleMS Demo</a>
            <div class="navbar-text text-light">
                <i class="fa fa-user"></i> <?php echo $_SESSION['user']; ?> |
                <i class="fa fa-clock-o"></i> <?php echo $current_utc; ?> UTC
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Dashboard Summary -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title">Available Vehicles</h5>
                        <h2>3</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-white">
                    <div class="card-body">
                        <h5 class="card-title">In Maintenance</h5>
                        <h2>1</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title">Active Bookings</h5>
                        <h2>1</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h5 class="card-title">Pending Requests</h5>
                        <h2>2</h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <button class="btn btn-primary me-2" data-bs-toggle="modal" data-bs-target="#bookVehicleModal">
                            <i class="fa fa-plus"></i> Book Vehicle
                        </button>
                        <button class="btn btn-success me-2" data-bs-toggle="modal" data-bs-target="#addVehicleModal">
                            <i class="fa fa-car"></i> Add Vehicle
                        </button>
                        <button class="btn btn-warning me-2">
                            <i class="fa fa-wrench"></i> Schedule Maintenance
                        </button>
                        <button class="btn btn-info">
                            <i class="fa fa-file-text"></i> Generate Report
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Active Bookings -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Active Bookings</h5>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Vehicle</th>
                            <th>User</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Purpose</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Tesla Model 3 (XYZ789)</td>
                            <td>ayik</td>
                            <td>2025-03-03 09:00:00</td>
                            <td>2025-03-05 18:00:00</td>
                            <td>Business trip</td>
                            <td><span class="badge bg-success">Approved</span></td>
                            <td>
                                <button class="btn btn-sm btn-info">Details</button>
                                <button class="btn btn-sm btn-danger">Cancel</button>
                            </td>
                        </tr>
                        <!-- Add more sample bookings here -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Vehicle Fleet -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Vehicle Fleet</h5>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Vehicle Number</th>
                            <th>Model</th>
                            <th>Brand</th>
                            <th>Year</th>
                            <th>Status</th>
                            <th>Last Maintenance</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $stmt = $db->query("SELECT * FROM vehicles");
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            $status_class = [
                                'available' => 'success',
                                'maintenance' => 'warning',
                                'in_use' => 'primary'
                            ][$row['status']];
                            
                            echo "<tr>
                                <td>{$row['vehicle_number']}</td>
                                <td>{$row['model']}</td>
                                <td>{$row['brand']}</td>
                                <td>{$row['year']}</td>
                                <td><span class='badge bg-{$status_class}'>{$row['status']}</span></td>
                                <td>2025-02-15</td>
                                <td>
                                    <button class='btn btn-sm btn-primary'>Edit</button>
                                    <button class='btn btn-sm btn-info'>History</button>
                                    <button class='btn btn-sm btn-warning'>Maintain</button>
                                </td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Book Vehicle Modal -->
    <div class="modal fade" id="bookVehicleModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Book a Vehicle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="bookingForm">
                        <div class="mb-3">
                            <label>Vehicle</label>
                            <select class="form-control" required>
                                <option value="1">Toyota Camry (ABC123)</option>
                                <option value="4">BMW X5 (GHI789)</option>
                                <option value="5">Ford F-150 (JKL012)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>Start Date & Time</label>
                            <input type="datetime-local" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>End Date & Time</label>
                            <input type="datetime-local" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Purpose</label>
                            <textarea class="form-control" required></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Submit Booking</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>