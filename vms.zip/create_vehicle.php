<?php
include_once 'config/database.php';
include_once 'classes/Vehicle.php';

$database = new Database();
$db = $database->getConnection();
$vehicle = new Vehicle($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vehicle->vehicle_number = $_POST['vehicle_number'];
    $vehicle->model = $_POST['model'];
    $vehicle->brand = $_POST['brand'];
    $vehicle->year = $_POST['year'];
    $vehicle->status = $_POST['status'];

    if($vehicle->create()) {
        header("Location: index.php");
    } else {
        echo "<div class='alert alert-danger'>Unable to create vehicle.</div>";
    }
}
?>